(() => {
  "use strict";

  const navButtons = Array.from(document.querySelectorAll("[data-view-target]"));
  const views = Array.from(document.querySelectorAll("section[data-view]"));
  const globalStatus = document.getElementById("globalStatus");
  const permissionDemo = document.getElementById("permissionDemo");
  const permissionMessage = document.getElementById("permissionMessage");
  const serviceForm = document.getElementById("serviceForm");
  const serviceUrl = document.getElementById("serviceUrl");
  const serviceMessage = document.getElementById("serviceMessage");
  const serviceLink = document.getElementById("serviceLink");
  const historySearch = document.getElementById("historySearch");
  const demoList = document.getElementById("demoList");
  const demoEmpty = document.getElementById("demoEmpty");
  const historyConfirm = document.getElementById("historyConfirm");
  const demoClear = document.querySelector('[data-action="demo-clear"]');

  const permissionCopy = {
    granted: {
      message: "Estado demonstrativo: a permissão seria concedida, mas nenhuma captura acontece aqui.",
      className: "state-granted"
    },
    denied: {
      message: "Estado demonstrativo: a permissão foi negada. Use o suporte do serviço oficial; esta extensão não tenta novamente.",
      className: "state-denied"
    },
    blocked: {
      message: "Estado demonstrativo: o navegador bloqueou a permissão. Revise as configurações apenas no contexto oficial.",
      className: "state-blocked"
    }
  };

  const fixtureSeed = [
    {
      id: "fixture-1",
      service: "portal.alfa.example",
      date: "29/10/2026 · 14:20",
      detail: "Exemplo de preparo concluído; nenhuma identidade foi confirmada."
    },
    {
      id: "fixture-2",
      service: "conta.beta.example",
      date: "28/10/2026 · 09:05",
      detail: "Estado de câmera simulado para teste de mensagens."
    },
    {
      id: "fixture-3",
      service: "sandbox.gamma.example",
      date: "25/10/2026 · 17:42",
      detail: "Registro sintético para exercitar busca e restauração."
    }
  ];

  let demoRecords = makeFixtures();

  function makeFixtures() {
    return fixtureSeed.map((fixture) => ({ ...fixture }));
  }

  function setGlobalStatus(message) {
    globalStatus.textContent = message;
  }

  function focusViewHeading(viewName) {
    const heading = document.getElementById(`title-${viewName}`);
    if (heading) {
      heading.focus({ preventScroll: true });
    }
  }

  function showView(viewName, shouldFocus = true) {
    setGlobalStatus("");
    document.getElementById("appMain").scrollTop = 0;
    views.forEach((view) => {
      const isActive = view.dataset.view === viewName;
      view.hidden = !isActive;
      view.setAttribute("aria-hidden", String(!isActive));
    });

    navButtons.forEach((button) => {
      const isActive = button.dataset.viewTarget === viewName;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-pressed", String(isActive));
      if (isActive) {
        button.setAttribute("aria-current", "page");
      } else {
        button.removeAttribute("aria-current");
      }
    });

    if (shouldFocus) {
      focusViewHeading(viewName);
    }
  }

  function updatePermissionMessage() {
    const selected = permissionCopy[permissionDemo.value] || permissionCopy.granted;
    permissionMessage.textContent = selected.message;
    permissionMessage.className = `state-message ${selected.className}`;
  }

  function setServiceMessage(message, isError = false, isSuccess = false) {
    serviceMessage.textContent = message;
    serviceMessage.classList.toggle("is-error", isError);
    serviceMessage.classList.toggle("is-success", isSuccess);
  }

  function invalidateServiceLink() {
    serviceLink.hidden = true;
    serviceLink.removeAttribute("href");
    serviceUrl.removeAttribute("aria-invalid");
    setServiceMessage("Endereço alterado. Valide o formato novamente; nenhum endereço é aberto automaticamente.");
  }

  function validateServiceUrl(event) {
    event.preventDefault();

    const rawValue = serviceUrl.value.trim();
    serviceLink.hidden = true;
    serviceLink.removeAttribute("href");

    if (!rawValue) {
      serviceUrl.setAttribute("aria-invalid", "true");
      setServiceMessage("Informe um endereço HTTPS para validar apenas o formato.", true);
      return;
    }

    let parsedUrl;
    try {
      parsedUrl = new URL(rawValue);
    } catch (error) {
      serviceUrl.setAttribute("aria-invalid", "true");
      setServiceMessage("Endereço inválido. Use um endereço HTTPS completo.", true);
      return;
    }

    const schemeEnd = rawValue.indexOf("://");
    const authority = schemeEnd >= 0 ? rawValue.slice(schemeEnd + 3).split(/[\/?#]/, 1)[0] : "";
    const hasUserInfo = Boolean(parsedUrl.username || parsedUrl.password || authority.includes("@"));
    const hasDisallowedParts = Boolean(hasUserInfo || parsedUrl.search || parsedUrl.hash || rawValue.includes("?") || rawValue.includes("#"));
    if (parsedUrl.protocol !== "https:" || !parsedUrl.hostname || hasDisallowedParts) {
      serviceUrl.setAttribute("aria-invalid", "true");
      setServiceMessage("Use HTTPS sem usuário, senha, consulta ou fragmento. Nada foi aberto.", true);
      return;
    }

    serviceUrl.removeAttribute("aria-invalid");
    serviceLink.href = parsedUrl.href;
    serviceLink.hidden = false;
    setServiceMessage("Formato HTTPS aceito localmente. A oficialidade não foi verificada; a abertura continua manual.", false, true);
    setGlobalStatus("Endereço pronto para abertura manual.");
  }

  function createBadge(label, className) {
    const badge = document.createElement("span");
    badge.className = `badge ${className}`;
    badge.textContent = label;
    return badge;
  }

  function createDemoRow(record, query) {
    const row = document.createElement("article");
    row.className = "demo-row";

    const rowHeader = document.createElement("div");
    rowHeader.className = "demo-row-header";

    const service = document.createElement("p");
    service.className = "demo-service";
    service.textContent = record.service;

    const date = document.createElement("time");
    date.className = "demo-date";
    date.textContent = record.date;

    rowHeader.append(service, date);

    const detail = document.createElement("p");
    detail.className = "demo-detail";
    detail.textContent = record.detail;

    const badges = document.createElement("div");
    badges.className = "demo-badges";
    badges.setAttribute("role", "group");
    badges.setAttribute("aria-label", "Registro de demonstração");
    badges.append(
      createBadge("Fictício", "badge-fictitious"),
      createBadge("Simulado", "badge-simulated"),
      createBadge("Não verificado", "badge-unverified")
    );

    row.append(rowHeader, detail, badges);

    if (query && !`${record.service} ${record.date} ${record.detail}`.toLocaleLowerCase("pt-BR").includes(query)) {
      row.classList.add("is-hidden");
      row.hidden = true;
    }

    return row;
  }

  function renderDemoHistory() {
    const query = historySearch.value.trim().toLocaleLowerCase("pt-BR");
    const fragment = document.createDocumentFragment();
    let visibleCount = 0;

    demoRecords.forEach((record) => {
      const row = createDemoRow(record, query);
      if (!row.hidden) {
        visibleCount += 1;
      }
      fragment.append(row);
    });

    demoList.replaceChildren(fragment);
    demoEmpty.hidden = visibleCount !== 0;
    if (demoRecords.length === 0) {
      demoEmpty.textContent = "Os exemplos foram limpos. Use Restaurar exemplos para recriá-los nesta sessão.";
    } else if (visibleCount === 0) {
      demoEmpty.textContent = "Nenhum exemplo corresponde à busca.";
    }
    demoClear.disabled = demoRecords.length === 0;
  }

  function openClearConfirmation() {
    if (demoRecords.length === 0) {
      setGlobalStatus("Não há exemplos para limpar.");
      return;
    }
    historyConfirm.hidden = false;
    setGlobalStatus("Confirme se deseja limpar somente os exemplos fictícios.");
    const cancelButton = document.querySelector('[data-action="demo-cancel"]');
    if (cancelButton) {
      cancelButton.focus();
    }
  }

  function cancelClear() {
    historyConfirm.hidden = true;
    setGlobalStatus("Limpeza cancelada; os exemplos continuam disponíveis.");
    demoClear.focus();
  }

  function confirmClear() {
    demoRecords = [];
    historyConfirm.hidden = true;
    renderDemoHistory();
    setGlobalStatus("Exemplos fictícios limpos. O histórico real continua vazio e intocado.");
    demoClear.focus();
  }

  function restoreDemo() {
    demoRecords = makeFixtures();
    historySearch.value = "";
    renderDemoHistory();
    setGlobalStatus("Três exemplos fictícios foram restaurados nesta sessão.");
  }

  navButtons.forEach((button) => {
    button.addEventListener("click", () => {
      showView(button.dataset.viewTarget);
    });
  });

  permissionDemo.addEventListener("change", updatePermissionMessage);
  serviceForm.addEventListener("submit", validateServiceUrl);
  serviceUrl.addEventListener("input", invalidateServiceLink);
  historySearch.addEventListener("input", renderDemoHistory);

  document.querySelector('[data-action="demo-clear"]').addEventListener("click", openClearConfirmation);
  document.querySelector('[data-action="demo-cancel"]').addEventListener("click", cancelClear);
  document.querySelector('[data-action="demo-confirm"]').addEventListener("click", confirmClear);
  document.querySelector('[data-action="demo-restore"]').addEventListener("click", restoreDemo);

  window.addEventListener("pagehide", () => {
    demoRecords = [];
    serviceUrl.value = "";
    serviceUrl.removeAttribute("aria-invalid");
    serviceLink.hidden = true;
    serviceLink.removeAttribute("href");
    setServiceMessage("Nenhum endereço foi validado.");
    historySearch.value = "";
    historyConfirm.hidden = true;
    permissionDemo.value = "granted";
    updatePermissionMessage();
    setGlobalStatus("");
    renderDemoHistory();
  });

  showView("prepare", false);
  updatePermissionMessage();
  renderDemoHistory();
  focusViewHeading("prepare");
})();
