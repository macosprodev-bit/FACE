# Instalar e testar o Verifica

Esta é uma extensão **de teste**, não uma ferramenta de autenticação. Ela não substitui a câmera, não cria webcam virtual e não altera o vídeo de sites ou aplicativos. O popup orienta a preparação e mostra exemplos fictícios. Sem provedor conectado, não registra sucesso real nem oferece upload para verificação.

## Chrome ou Edge no Windows

Baixe `verifica-extensao-teste.zip` e extraia em uma pasta estável, por exemplo `Documentos\Verifica-teste`. A pasta selecionada na instalação deve conter `manifest.json` diretamente; não selecione uma pasta acima dele.

No Chrome, abra `chrome://extensions`; no Edge, abra `edge://extensions`. Ative **Modo do desenvolvedor**, escolha **Carregar sem compactação** e selecione a pasta extraída. Fixe o Verifica no menu de extensões e clique no ícone para abrir o popup. Esse procedimento é a instalação local para teste documentada por Chrome e Edge, não publicação em loja. [1] [2]

Depois de alterar código, use **Recarregar** no cartão da extensão. Para remover, escolha **Remover** na mesma página. Uma política corporativa pode impedir instalação em modo de desenvolvedor; não tente contornar a administração do dispositivo.

## Firefox: instalação temporária de teste

Abra `about:debugging`, escolha **Este Firefox** e **Carregar extensão temporária**. Selecione o `manifest.json` extraído ou o ZIP com manifesto na raiz. A instalação temporária termina ao remover a extensão ou reiniciar o Firefox. Uso normal distribuído a usuários exige empacotamento/assinatura e aprovação adequados; não confundir teste temporário com extensão publicada. [3]

O pacote usa Manifest V3 e não depende de service worker ou API específica de Chrome. Isso reduz diferenças de plataforma, mas não comprova compatibilidade de todas as versões: registre navegador/versão no teste da equipe. A execução no Windows, Edge e Firefox permanece pendente até ser realizada nesses ambientes.

## O que testar no popup

Percorra Preparação, Ajuda, Histórico e Privacidade com mouse e teclado. Confira foco visível, leitura dos títulos/avisos e os marcadores de simulação. A ajuda de câmera tem estados demonstrativos; nenhuma escolha concede permissão real. A câmera deve ser solicitada pelo site oficial, após ação clara da pessoa e de acordo com a integração do serviço.

No Histórico, o bloco real deve ficar vazio. Busque e apague apenas os exemplos fictícios; teste cancelar/confirmar/restaurar. Feche e reabra o popup: exemplos e demais estados retornam ao estado inicial da demonstração, sem leitura de autenticações reais.

O endereço de serviço, se informado, fica somente na memória do popup. A extensão valida a forma de uma URL HTTPS sem credenciais, query ou fragmento, mas não confirma que o domínio pertence ao seu provedor. A abertura ocorre somente após ação manual e navega para o destino informado. Verifique o domínio com o serviço oficial antes de clicar. Não cole links que contenham tokens.

## Privacidade desta versão

A extensão não tem permissões de páginas, câmera, abas, host ou armazenamento. Não injeta content scripts nem modifica pedidos/streams. O código não usa analytics, cookies, persistência local, fetch, XHR ou beacon. Os exemplos e campos são mantidos só na memória do documento do popup; não há histórico real, upload ou captura de mídia. Fechar o popup encerra esse estado; isso não é uma promessa de limpeza forense da memória do sistema.

Não digite dados pessoais em campos de teste. A extensão não solicita CPF, senha, token, imagem facial ou biometria. Abrir um endereço manualmente faz a navegação normal do navegador e está sujeito à política do site de destino; a restrição de rede do popup não impede essa navegação solicitada pela pessoa.

Esta descrição corresponde ao pacote de teste, não a uma política jurídica revisada para produção. Uma futura integração precisa definir responsável pelo tratamento, finalidade, bases aplicáveis, retenção/exclusão, direitos, canal de suporte, TLS, destinos autorizados e revisão de segurança. Histórico real deve receber somente sucessos autênticos do serviço, com dados mínimos e sem segredos ou mídia.

## Integridade do download

Confira o ZIP antes de extrair com o SHA-256 entregue. No PowerShell, execute `Get-FileHash .\verifica-extensao-teste.zip -Algorithm SHA256` e compare com o arquivo `.sha256` obtido por canal confiável. Hash confirma correspondência dos bytes, não autoria nem segurança; se ZIP e hash forem alterados juntos, essa checagem isolada não detecta a troca.

Não instale em máquinas de produção sem revisão da equipe. Não publicar nas lojas nesta etapa.

## Referências

[1]: https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world "Chrome Extensions: Hello World e instalação local"
[2]: https://learn.microsoft.com/en-us/microsoft-edge/extensions/getting-started/extension-sideloading "Microsoft Edge: sideload de extensão para teste"
[3]: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/ "Mozilla: instalação temporária no Firefox"
