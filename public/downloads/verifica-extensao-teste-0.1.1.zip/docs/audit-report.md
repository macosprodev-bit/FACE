# Auditoria automática — Verifica

Data UTC: 2026-10-29T21:54:23.737346+00:00. Chromium: 156.0.8078.47. axe-core: 4.14.0.

Estados testados: 12; não testados: 0.
Violações por estado: 0; resultados axe incompletos: 3; falhas complementares de teclado: 0.
Indicadores de foco para revisão heurística: 0.

Contagens podem repetir o mesmo problema entre estados. Sem violação automática não significa conformidade WCAG ou aprovação de privacidade.

## Teclado e foco
- navegar help com Enter e focar título: verificação executada sem falha.
- navegar history com Enter e focar título: verificação executada sem falha.
- navegar privacy com Enter e focar título: verificação executada sem falha.
- navegar prepare com Enter e focar título: verificação executada sem falha.

O outline é somente um indicador heurístico; leitor de tela, ordem de foco e percepção visual continuam exigindo inspeção humana.

## Estados auditados

### preparar/concedida-simulada
Estado: tested; violações: 0; incompletos: 1.
- Revisão pendente `color-contrast`: Elements must meet minimum color contrast ratio thresholds.
  Alvo técnico: `[".section-mark"]`.
  Alvo técnico: `["li:nth-child(1) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(2) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(3) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(4) > .check-icon[aria-hidden=\"true\"]"]`.

### preparar/negada-simulada
Estado: tested; violações: 0; incompletos: 1.
- Revisão pendente `color-contrast`: Elements must meet minimum color contrast ratio thresholds.
  Alvo técnico: `[".section-mark"]`.
  Alvo técnico: `["li:nth-child(1) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(2) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(3) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(4) > .check-icon[aria-hidden=\"true\"]"]`.

### preparar/bloqueada-simulada
Estado: tested; violações: 0; incompletos: 1.
- Revisão pendente `color-contrast`: Elements must meet minimum color contrast ratio thresholds.
  Alvo técnico: `[".section-mark"]`.
  Alvo técnico: `["li:nth-child(1) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(2) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(3) > .check-icon[aria-hidden=\"true\"]"]`.
  Alvo técnico: `["li:nth-child(4) > .check-icon[aria-hidden=\"true\"]"]`.

### ajuda/inicial
Estado: tested; violações: 0; incompletos: 0.

### ajuda/url-invalida
Estado: tested; violações: 0; incompletos: 0.

### ajuda/url-formato-valido-sem-navegar
Estado: tested; violações: 0; incompletos: 0.

### historico/exemplos
Estado: tested; violações: 0; incompletos: 0.

### historico/busca-sem-resultado
Estado: tested; violações: 0; incompletos: 0.

### historico/confirmacao
Estado: tested; violações: 0; incompletos: 0.

### historico/exemplos-apagados
Estado: tested; violações: 0; incompletos: 0.

### historico/exemplos-restaurados
Estado: tested; violações: 0; incompletos: 0.

### privacidade/inicial
Estado: tested; violações: 0; incompletos: 0.

## Limites e privacidade

Perfil temporário isolado; a CSP e os arquivos da extensão não foram alterados. O motor local foi injetado apenas pela automação de teste.
O teste bloqueia HTTP/HTTPS e não abre o link de serviço, solicita câmera ou inicia autenticação. Relatórios não incluem HTML bruto nem valores de formulário.
Revisar com leitor de tela, zoom, teclado, visibilidade do foco, contraste inconclusivo e compreensão dos marcadores simulados. Não é uma certificação WCAG.

## Referências

[1]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html "W3C: contraste mínimo"
[2]: https://github.com/dequelabs/axe-core "axe-core: documentação e resultados incompletos"
