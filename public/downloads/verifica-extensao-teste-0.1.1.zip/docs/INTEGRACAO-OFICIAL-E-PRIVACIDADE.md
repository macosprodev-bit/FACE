# Integração oficial e privacidade

## Estado atual e decisão

A extensão é hoje um protótipo educativo Manifest V3, sem permissões, com `connect-src 'none'`, sem câmera, provedor identificado ou histórico real. Este guia prepara uma integração futura, mas não implementa nem afirma conexão de produção. Não usar OAuth falso, endpoint fictício, token de demonstração ou botão que transforme mensagem do cliente em sucesso.

A política padrão é **BFF (Backend for Frontend) + página oficial HTTPS first-party**. A extensão abre essa página somente por ação manual. O navegador faz login no domínio oficial e o BFF fala com o provedor. A extensão não recebe segredo, senha, código, access token ou refresh token. Tokens OAuth podem existir apenas no BFF, em cofre de segredos e, quando indispensável, transitoriamente em memória ou armazenamento criptografado; nunca na extensão, histórico local ou logs. Se nenhum token puder ser guardado em qualquer camada, mantenha a extensão educativa.

Nessa arquitetura inicial, manter o histórico real no backend e exibi-lo na página oficial autenticada. A extensão não passa a ler esse histórico automaticamente. Para exibi-lo no popup no futuro, projetar e validar uma sessão/canal autorizado por usuário e tenant, além das permissões e da política de origem necessárias; uma URL informada ou mensagem local não autentica o acesso aos eventos.

## Fluxo de login OAuth/OIDC

1. A extensão permanece offline enquanto não houver integração autorizada. O controle futuro abre manualmente URL HTTPS fixa da página first-party. O endpoint OAuth não pode ser arbitrário: o BFF aplica allowlist de emissores e endpoints registrados. O popup não coleta credenciais.

2. Para o BFF, use Authorization Code Flow com PKCE `S256`, `state` aleatório vinculado à sessão e uso único. Registre cada redirect completo e compare exatamente, rejeitando variações de host, caminho, query ou fragmento; não crie open redirect. RFC 9700 recomenda PKCE `S256`, `state`/`nonce` transacionais e escopos mínimos. [1]

3. O callback do BFF troca o código no token endpoint, nunca no popup. Antes de criar sessão, valide TLS, `iss` contra o emissor permitido, assinatura usando as chaves publicadas pelo emissor (JWKS), `aud` contendo o `client_id` correto, `exp`, `iat` quando aplicável e `nonce` igual ao valor armazenado no estado do servidor. A especificação OIDC exige a validação de emissor, audiência, assinatura, expiração e nonce; um JWT assinado pelo cliente, isoladamente, não é prova de autenticidade sem validação no servidor. [3]

4. Faça a autorização de negócio depois da autenticação: vincule o sujeito a usuário e tenant permitidos, aplique escopos mínimos por recurso e rejeite tenant vindo apenas do navegador. Proteja replay com estado server-side single-use, expiração curta, nonce/JTI quando disponível, consumo atômico e timestamps. Duplicatas devem ser idempotentes.

5. Depois do callback, entregue somente sessão própria por cookie `HttpOnly; Secure`, com `SameSite` calibrado à topologia real (`Lax` quando compatível; `None` só se cross-site exigir, com CSRF adicional). Não presumir que essa sessão funcionará no iframe cross-site do preview sem adaptação. A RFC 8252 exige agente externo, tipicamente navegador, para aplicativos nativos e explica por que segredos estáticos distribuídos não são confidenciais. [2] Para extensão, confirmar o contrato e a API do navegador; `client_secret` nunca fica no popup.

Integração direta pela extensão só deve ser considerada se o provedor documentar a extensão como cliente público, seu redirect registrado e a API oficial de lançamento no navegador, como `launchWebAuthFlow` quando aplicável. Ainda valem PKCE, `state`, allowlist e ausência de segredo no pacote. Não adicione permissão de identidade por antecipação nem invente esquema de retorno.

## Login não é verificação facial

OAuth trata de autorização delegada; OIDC adiciona a camada de autenticação e identificação por claims validadas. Nenhum deles certifica por si só captura de face, vivacidade (liveness) ou titularidade documental. “Auth success” não é sucesso facial. Facial/liveness é outro fluxo na página oficial, com garantia, consentimento e resultado definidos pelo contrato do provedor. [3]

O webhook facial deve autenticar o evento conforme o contrato oficial: verificar assinatura HMAC/assimétrica e o material assinado exatamente no esquema documentado. Quando a assinatura usar o **corpo bruto**, preservar os bytes antes de fazer parsing; não pressupor que todo protocolo assina esse mesmo formato. Validar timestamp/janela quando previstos, identificação e rotação de chave e proteção contra replay. Rejeitar eventos sem a autenticação exigida, com assinatura inválida, repetidos ou incompatíveis com a ordem de estados permitida. Usar idempotência e consumo atômico. Estados `pending`, `failed`, `canceled` ou desconhecidos nunca viram `success`; consultar a API oficial do provedor quando o contrato exigir confirmação. Não confiar em JWT ou JSON originado pelo cliente como prova sem validação no backend.

A extensão não injeta stream em aba protegida, não cria dispositivo virtual e não usa câmera local. Upload só poderá aparecer depois de capacidade oficialmente atestada pelo servidor: método aceito, destino, consentimento, formatos e limite. Checkbox, campo local ou flag `provider-empty` nunca habilita alternativa oficial. Sem provedor configurado, oriente outro dispositivo ou suporte do serviço, sem simular permissão concedida.

## Dados, histórico e LGPD

A minimização deve seguir finalidade, adequação, necessidade, transparência, segurança, prevenção e responsabilização; a página oficial do governo resume esses princípios da LGPD. [5] O BFF deve separar dados de operação, identidade e auditoria e documentar controlador, operadores, finalidade, base legal, acesso e eliminação. Faça revisão jurídica e de privacidade antes do cadastro real.

O histórico autorizado deve guardar somente `opaque_id`, `provider_allowed_label`, `confirmed_at` e `event_type` permitido. Não guardar token bruto, código OAuth, senha, imagem, vídeo, biometria, CPF ou payload facial. A retenção é política aprovada, não prazo universal: defina TTL por evento, apague cópias/backups ao vencer e mantenha só auditoria sem PII (event_type, resultado, identificador técnico não reversível e data), incluindo `delete` quando aplicável, com exclusão por tenant/data. OWASP recomenda não registrar tokens, senhas, sessões, chaves ou dados pessoais sensíveis; mascare, remova ou pseudonimize quando necessário. [4]

A extensão continua sem histórico real até que o servidor confirme evento autêntico. Ela também não armazena senha, token, mídia, biometria ou telemetria por conveniência. A CSP atual `connect-src 'none'` significa nenhuma conexão: não mudar para `*`. Se no futuro a arquitetura exigir chamadas, altere somente para o host HTTPS allowlisted do BFF e peça a menor permissão tipada necessária; não adicionar `tabs`, `storage`, câmera ou content scripts sem uma decisão específica e documentada.

## Testes de integração futuros (não executados)

Antes de produção, teste em perfil isolado e registre navegador/versão. Cubra `state` ausente, incorreto, reutilizado e expirado; PKCE ausente, downgrade e verifier errado; redirect alterado; emissor, `aud`, JWKS, assinatura, nonce e `exp` inválidos; token forjado; sessão expirada; tenant não autorizado; TLS recusado; replay de código, nonce, JTI e webhook; webhook duplicado, sem assinatura, fora de ordem, `pending` e `failed`; limite, idempotência; histórico só após confirmação; exclusão por tenant/data; ausência de senha, token, imagem e CPF em histórico/logs; e erro de rede sem fail-open. Não executar POSTs, GET de dados do usuário ou `getUserMedia` como atalho.

## Pré-requisitos e bloqueio atual

A integração está bloqueada até existir: provedor e documentação oficial; issuer, endpoints e JWKS; cadastro do cliente no BFF; scopes/claims; redirects e domínios HTTPS; sessão/CSRF; contrato de webhook, assinatura, rotação, idempotência e estados; cofre; finalidade, operadores, retenção e eliminação; aviso de privacidade, revisão LGPD e suporte. Sem provider, domínio, client metadata e contrato de evento, não há implementação segura.

## Referências

[1]: https://www.rfc-editor.org/rfc/rfc9700/ "RFC 9700: Best Current Practice for OAuth 2.0 Security"
[2]: https://www.rfc-editor.org/rfc/rfc8252/ "RFC 8252: OAuth 2.0 for Native Apps"
[3]: https://openid.net/specs/openid-connect-core-1_0.html "OpenID Connect Core 1.0 incorporating errata set 2"
[4]: https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html "OWASP Logging Cheat Sheet"
[5]: https://www.gov.br/mds/pt-br/acesso-a-informacao/lgpd/principios-da-lgpd "Princípios da LGPD"
