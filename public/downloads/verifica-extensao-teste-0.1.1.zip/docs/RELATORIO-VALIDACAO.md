# Verifica 0.1.1 — validação do pacote de teste

A extensão Manifest V3 foi carregada como extensão descompactada em perfil temporário isolado de Chromium 156.0.8078.47 no sandbox. O popup foi aberto na origem real da extensão, não servido como página web. O teste terminou com sucesso e o perfil temporário foi removido. Isso não instala a extensão no computador do usuário nem comprova funcionamento em Chrome/Edge/Firefox no Windows.

## Resultado observado

O teste percorreu Preparação, Ajuda, Histórico e Privacidade; exercitou teclado e foco no título, estados simulados concedida/negada/bloqueada, busca de exemplos, cancelamento/confirmação de limpeza, restauração e reset ao recarregar. Verificou URL HTTPS sem credenciais/query/fragmento, invalidação do link após mudança do campo, ausência de file input e de APIs de câmera, transmissão e armazenamento persistente.

Não foram observados erros JavaScript nem requisições HTTP/HTTPS originadas pelo popup durante o smoke test. O link de navegação manual não foi aberto. Nenhuma câmera, documento, mídia facial, login ou provedor real participou do teste. O bloco de histórico real permaneceu sem integração; exemplos são fictícios e separados.

A revisão visual identificou e corrigiu mensagem comprimida e rolagem retida ao trocar de tela. O foco foi alterado de âmbar para azul escuro para aumentar seu contraste com superfícies claras. Os pares principais de texto foram calculados: texto secundário sobre fundo claro 5,61:1, texto de botão sobre azul 11,61:1 e badge fictício 6,48:1. Esses cálculos pontuais e a automação não constituem certificação WCAG ou auditoria integral de acessibilidade.

Na versão 0.1.1, os contêineres nomeados de badges receberam `role="group"` e a região rolável passou a ter `tabindex="0"`. A auditoria Python com axe-core 4.14.0 percorreu 12 estados: zero violações automáticas, zero estados não testados e zero falhas complementares de navegação por teclado. Restaram três ocorrências inconclusivas de `color-contrast`, nos mesmos símbolos decorativos dos três estados de Preparação. Elas não foram suprimidas nem marcadas como aprovadas; revisar manualmente. O teste negativo detectou contraste deliberadamente ruim em DOM temporário e confirmou que os arquivos da extensão foram preservados.

![Popup inicial no Chromium](popup-chromium.png)

## Limites de segurança desta versão

O manifesto não declara permissões privilegiadas, acesso a host, background, content scripts ou armazenamento. CSP restringe scripts/estilos locais e bloqueia conexões de rede do popup. Os ícones reutilizam a marca original. O manifesto contém ID de teste Firefox e declaração de ausência de coleta; não está assinado nem submetido a lojas.

O endereço de serviço é informado pela pessoa e não é certificado pela extensão. Abrir o link manualmente é uma navegação normal sujeita ao site de destino. Não existe fluxo de upload nem câmera no popup; as funções oficiais permanecem no serviço autorizado.

## Ainda não validado

A equipe deve testar instalação/atualização/remoção em Chrome, Edge e Firefox no Windows, registrar versões e conferir comportamento do popup real na barra de ferramentas. No Firefox, usar instalação temporária; não pressupor aprovação/assinatura. Conferir leitor de tela, contraste em todos os estados, escala/zoom e navegação com teclado assistivo.

Histórico de sucessos reais, autenticação de eventos, retenção/exclusão auditável, integração autorizada de mídia/câmera, TLS de integração, consentimento, política jurídica, termos das lojas, suporte e monitoramento seguro são pendências de produção. Nenhuma delas foi simulada como implementada.

## Reexecutar

No ambiente de teste com Python Playwright e Chromium instalado em `/usr/bin/chromium`, executar `python3 tests/smoke_extension.py` a partir da pasta de fonte. O teste usa perfil temporário e não acessa destinos externos. O pacote instalável não depende de Python, Node ou servidor.

Os scripts da habilidade de benchmark também passaram em testes unitários sintéticos, incluindo ausência não convertida em zero, cache isolado por origem de teste/produção e integração coletor → síntese offline. Nenhuma coleta real Similarweb ou sessão real de usabilidade foi executada para esses testes.
